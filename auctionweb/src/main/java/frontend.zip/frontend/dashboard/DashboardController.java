package frontend.dashboard;

import de.jensd.fx.glyphs.fontawesome.FontAwesomeIcon;
import de.jensd.fx.glyphs.fontawesome.FontAwesomeIconView;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.event.ActionEvent;
import java.io.IOException;

public class DashboardController {

    @FXML
    private StackPane contentArea;

    @FXML
    private Button btnHome;

    @FXML
    private Button btnSignup;

    @FXML
    public void initialize() {
        setupMenuButtons();
        // Nạp mặc định trang chủ khi khởi tạo
        onMenuHomeClick();
    }

    private void setupMenuButtons() {
        try {
            FontAwesomeIconView homeIcon = new FontAwesomeIconView(FontAwesomeIcon.HOME);
            homeIcon.setSize("1.6em");
            btnHome.setGraphic(homeIcon);

            FontAwesomeIconView userIcon = new FontAwesomeIconView(FontAwesomeIcon.USER_PLUS);
            userIcon.setSize("1.6em");
            btnSignup.setGraphic(userIcon);
        } catch (Exception e) {
            System.err.println("Lưu ý: FontAwesome không tải được. Kiểm tra thư viện glyphs.");
        }
    }

    private void changeView(String fxmlPath) {
        try {
            Parent view = FXMLLoader.load(getClass().getResource(fxmlPath));
            contentArea.getChildren().clear();
            contentArea.getChildren().add(view);
        } catch (IOException e) {
            System.err.println("Không tìm thấy file FXML: " + fxmlPath);
            e.printStackTrace();
        }
    }

    @FXML
    private void onMenuSignupClick() {
        changeView("/fxml/signup.fxml");
    }

    @FXML
    private void onMenuHomeClick() {
        changeView("/fxml/home.fxml"); 
    }

    @FXML
    private void handleLogout(ActionEvent event) {
        try {
            Parent signinRoot = FXMLLoader.load(getClass().getResource("/fxml/signin.fxml"));
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(signinRoot));
            stage.setTitle("Đăng nhập");
            stage.centerOnScreen();
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}